function Error() {

    return (
        <>
            <h1> ERROR 404 found </h1>
        </>
    )
}

export default Error;